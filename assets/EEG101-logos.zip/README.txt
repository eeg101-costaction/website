EEG101 logo pack — COST Action CA24148
https://www.eeg101.eu/logos/

EEG101-logos/      EEG101 wordmark and brain mark, square and horizontal,
                   on white (B), transparent, and transparent without border.
COST-logos/        Official COST logos (RGB, dark grey, medium grey, white).
EU-funding-logos/  'Funded by the European Union' emblems, horizontal (EN-) and
                   vertical (EN V), in positive, negative, black, white and Pantone.

Brand colours: Azure #000099, Gold #FFCC00.
Typefaces: Comfortaa (headings), Lato (body).

All visible output produced with EEG101 support must acknowledge the COST Action.
Full guidance: https://www.eeg101.eu/logos/
